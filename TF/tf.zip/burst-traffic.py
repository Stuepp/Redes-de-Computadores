import matplotlib.pyplot as plt 
import numpy as np

time = np.array([0,1,2,3,4,5,6,7,8,9,10])
#plot 1, burst-traffic-udp:
y = np.array([11.4,11.9,11.9,11.9,11.9,11.9,11.9,11.9,11.9,11.9,0.512])
plt.subplot(1, 2, 1)
plt.plot(time,y)

#plot 2 burst-traffic-tcp:
"""y = np.array([11.5,11.9,12.0,11.9,11.9,12.0,11.9,11.9,12.0,11.9,0.512])
plt.subplot(1, 2, 2)
plt.plot(y)"""
fig, ax = plt.subplots()
ax.plot(np.array([11.4,11.9,11.9,11.9,11.9,11.9,11.9,11.9,11.9,11.9,0.512]), color='r')
ax.plot(np.array([11.5,11.9,12.0,11.9,11.9,12.0,11.9,11.9,12.0,11.9,0.512]), color='#4CAF50')
ax.set_xlabel('Tempo')
ax.set_ylabel('Retr (pacotes)')
ax.set_title('RENO - Cenário 1: Número de retransmissão de pacotes dos processos tcp com 2 processos')
ax.grid(True)


# plot 3 elephant-flow-up:
#y = np.array([11.5,11.9,12.0,11.9,11.9,12.0,11.9,11.9,12.0,11.9,0.512])
#plt.subplot(1, 2, 2)
#plt.plot(y)

# plot 4 elephant-flow-tcp:
#y = np.array([11.5,11.9,12.0,11.9,11.9,12.0,11.9,11.9,12.0,11.9,0.512])
#plt.subplot(1, 2, 2)
#plt.plot(y)

plt.savefig("teste")
