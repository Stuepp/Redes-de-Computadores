import matplotlib.pyplot as plt 
import numpy as np

retr2 = [np.array([11.4,11.9,11.9,11.9,11.9,11.9,11.9,11.9,11.9,11.9,0.512]), # estranhamente udp do elefante igual do burst
np.array([11.5,11.9,12.0,11.9,11.9,12.0,11.9,11.9,12.0,11.9,0.512])] # estranhamente tcp do elefante igual do burst

fig, ax = plt.subplots()
ax.plot(retr2[0], color='r')
ax.plot(retr2[1], color='#4CAF50')
ax.set_xlabel('Tempo')
ax.set_ylabel('Transfer')
ax.set_title('Elephant Flow Mesma Máquina - Gráfico de Vazão - R: UDP - G: TCP')
ax.grid(True)

plt.savefig("elephant")